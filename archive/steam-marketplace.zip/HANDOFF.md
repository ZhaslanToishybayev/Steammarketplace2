# 🎮 Steam Marketplace — Документация для разработчика

Привет! Это краткая документация по проекту. Ниже описано, что это за сайт, как его запустить и что было сделано.

---

## 📦 Что это?

Это **маркетплейс скинов CS2**, похожий на cs.money или DMarket.
- Пользователь логинится через Steam.
- Может покупать скины за внутренний баланс.
- Бот автоматически отправляет трейд-оффер в Steam.
- Есть корзина, история сделок, профиль пользователя.

---

## 🗂 Структура проекта

```
/apps
  /backend    — Node.js + Express сервер (API, Steam боты, БД)
  /frontend   — Next.js сайт (React, TypeScript)
```

---

## 🚀 Как запустить

### 1. Установи зависимости

```bash
cd apps/backend && npm install
cd ../frontend && npm install
```

### 2. Настрой окружение

Создай файл `.env` в `apps/backend/`:

```env
# База данных (PostgreSQL)
DATABASE_URL=postgresql://postgres:password@localhost:5432/steam_marketplace

# Steam API
STEAM_API_KEY=твой_ключ_steam
STEAM_RETURN_URL=http://localhost:3001/auth/steam/return
STEAM_REALM=http://localhost:3001/

# Боты (можно несколько)
STEAM_BOT_1_ACCOUNT_NAME=логин_аккаунта
STEAM_BOT_1_PASSWORD=пароль
STEAM_BOT_1_SHARED_SECRET=секрет_2FA
STEAM_BOT_1_IDENTITY_SECRET=секрет_подтверждения
STEAM_BOT_1_STEAM_ID=76561198xxxxxxxxx

# Фронтенд
FRONTEND_URL=http://localhost:3000
SESSION_SECRET=любая_длинная_строка
```

В `apps/frontend/` создай `.env.local`:

```env
NEXT_PUBLIC_BACKEND_URL=http://localhost:3001
```

### 3. Запусти PostgreSQL

Убедись, что база данных `steam_marketplace` существует.

```bash
# Создай базу данных
createdb -h localhost -U postgres steam_marketplace
```

### 4. Восстанови схему базы данных ⚠️ ВАЖНО

В архиве есть файл `database_schema.sql` — это все таблицы.

```bash
# Накати схему
psql -h localhost -U postgres steam_marketplace < database_schema.sql
```

Или через миграции (они лежат в `apps/backend/migrations/`):

```bash
cd apps/backend
node scripts/run_migrations.js
```

### 5. Запусти сервер

```bash
# Терминал 1: Backend
cd apps/backend && node src/server.js

# Терминал 2: Frontend
cd apps/frontend && npm run dev
```

Открой http://localhost:3000

---

## 🔧 Что было сделано (краткий лог)

### ✅ Основные фичи
- **Авторизация через Steam** — Passport.js + OpenID
- **Просмотр инвентаря бота** — скины синхронизируются в БД
- **Покупка скинов** — баланс списывается, бот отправляет оффер
- **Корзина** — можно купить несколько скинов за раз
- **Страница сделки** — статус обновляется в реальном времени

### 🐛 Исправленные баги
- **Пустая база после синхронизации** — была опечатка в названии колонки (`listing_status` → `status`)
- **Не показывался ник/аватар** — добавил колонки `username`, `avatar` в таблицу `users`
- **Сделка "зависала"** — бот не мог отправить оффер (Steam 502). Добавил:
  - Статус `error_sending` — сделка помечается как ошибочная
  - Кнопка "Повторить отправку" — пользователь сам перезапускает
  - Кнопка "Отменить и вернуть" — деньги возвращаются, скин освобождается

### 🛠 Технические улучшения
- Retry/Cancel эндпоинты: `/api/escrow/trades/:uuid/retry` и `/cancel`
- Обработка ошибок бота не ломает сделку
- UI показывает понятный статус при ошибках

---

## 📁 Важные файлы

| Файл | Описание |
|------|----------|
| `apps/backend/src/server.js` | Точка входа бэкенда |
| `apps/backend/src/routes/escrow.js` | Логика покупок и сделок |
| `apps/backend/src/services/steam-bot.service.js` | Класс Steam-бота |
| `apps/backend/src/routes/admin.js` | Синхронизация инвентаря бота |
| `apps/frontend/src/app/page.tsx` | Главная страница |
| `apps/frontend/src/app/trade/[tradeUuid]/page.tsx` | Страница сделки |
| `apps/frontend/src/lib/api.ts` | API-клиент фронтенда |

---

## ⚠️ Что нужно знать

1. **Steam боты требуют Steam Guard Mobile Authenticator** (shared_secret, identity_secret).
2. **Steam API иногда возвращает 502** — это нормально, пользователь может нажать "Повторить".
3. **База данных PostgreSQL** — не SQLite, не MySQL.
4. **Цены — заглушки** — в реальном проекте нужно подключить API цен (buff163, cs.money).

---

## 🤝 Контакты

Если что-то непонятно — пиши!

---

*Документация сгенерирована 16.12.2025*
