'use client';

import { useEffect, useState } from 'react';
import { useAdminApi } from '../../../hooks/useAdminAuth';
import { Card, CardContent, Badge, TableRowSkeleton } from '../../../components/ui';

interface AuditLog {
  id: number;
  admin_name: string;
  action: string;
  entity_type: string;
  entity_id: number;
  details: any;
  ip_address: string;
  created_at: string;
}

export default function AdminLogsPage() {
  const { apiCall } = useAdminApi();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<any>(null);

  useEffect(() => {
    loadLogs();
  }, [page]);

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const data = await apiCall(`/audit-logs?page=${page}&limit=50`);
      if (data.success) {
        setLogs(data.data.logs);
        setPagination(data.data.pagination);
      }
    } catch (err) {
      console.error('Failed to load logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getActionColor = (action: string) => {
    if (action.includes('DELETE') || action.includes('BAN')) return 'red';
    if (action.includes('CREATE') || action.includes('ADD')) return 'green';
    if (action.includes('UPDATE')) return 'orange';
    if (action.includes('LOGIN')) return 'blue';
    return 'default';
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Audit Logs</h1>
        <p className="text-[var(--text-secondary)] mt-1">
          {pagination ? `${pagination.total} total actions` : 'Loading...'}
        </p>
      </div>

      <Card>
        <CardContent className="p-0">
          <table className="table">
            <thead>
              <tr>
                <th>Admin</th>
                <th>Action</th>
                <th>Target</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => <TableRowSkeleton key={i} columns={4} />)
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-[var(--text-muted)]">
                    No audit logs yet
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id}>
                    <td className="font-medium">{log.admin_name || 'System'}</td>
                    <td>
                      <Badge variant={getActionColor(log.action) as any}>
                        {log.action}
                      </Badge>
                    </td>
                    <td className="text-[var(--text-muted)]">
                      {log.entity_type ? `${log.entity_type} #${log.entity_id}` : '—'}
                    </td>
                    <td className="text-[var(--text-muted)] text-sm">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
