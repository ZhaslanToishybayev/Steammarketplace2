"""Top-level package for the project.

This file makes `src` importable as a package during testing and runtime.
"""

__all__ = []
